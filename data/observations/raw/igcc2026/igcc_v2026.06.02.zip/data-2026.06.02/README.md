# Data repository for Indicators of Global Climate Change

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.7883757.svg)](https://doi.org/10.5281/zenodo.7883757)

This repository contains standardised data for figures and results used in the
Indicators of Global Climate Change 2025 paper, submitted to Earth System Science Data.

The below table details the author(s) of each dataset contained within the repository, and their homepages.

| Dataset | Author(s) | Original code location(s) |
| ------- | --------- | ------------------------ |
| Attribution of historical warming 1850-2025 | [Tristram Walsh](https://www.torch.ox.ac.uk/people/tristram-walsh),<br>[Aurélien Ribes](https://www.umr-cnrm.fr/spip.php?article23&lang=en),<br>[Nathan Gillett](https://profils-profiles.science.gc.ca/en/profile/dr-nathan-gillett),<br>[Chris Smith](https://cjsmith.eu) | https://github.com/ClimateIndicator/anthropogenic-warming-assessment |
| Anthropogenic ERF and warming by emitted species | [Zeke Hausfather](https://www.linkedin.com/in/zeke-hausfather-7327699/) | |
| Earth's energy uptake 1971-2025 | [Matthew Palmer](https://www.metoffice.gov.uk/research/people/matt-palmer),<br>[Karina von Schuckmann](http://kvonschuckmann.com/) | https://github.com/ClimateIndicator/ocean-heat-content |
| Effective radiative forcing 1750-2025 | [Chris Smith](https://cjsmith.eu),<br>[Piers Forster](https://environment.leeds.ac.uk/see/staff/1267/professor-piers-forster) | https://github.com/ClimateIndicator/forcing-timeseries |
| Global land precipitation 1891-2025 | Jeong-eun Yun,<br>[June-Yi Lee](https://ibsclimate.org/people/%EC%9D%B4%EC%A4%80%EC%9D%B4-june-yi-lee/) | |
| Global mean surface temperature anomalies 1850-2025 | [Blair Trewin](https://community.wmo.int/en/contacts/mr-blair-trewin) | https://github.com/ClimateIndicator/GMST |
| Global temperature extreme anomalies 1950-2025 | [Mathias Hauser](https://iac.ethz.ch/people-iac/person-detail.html?persid=146568),<br> [Dominik Schumacher](https://usys.ethz.ch/en/people/profile.MTcwNDMx.TGlzdC82MzcsMzIwMTk3MjIy.html),<br> [Sonia Seneviratne](https://iac.ethz.ch/people-iac/person-detail.NTQ3Nzg=.TGlzdC82MzcsLTE5NDE2NTk2NTg=.html) | https://github.com/ClimateIndicator/cip_extremes |
| Greenhouse gas concentrations 1750-2025 | [Chris Smith](https://cjsmith.eu),<br> [Jens Muhle](https://jmuhle.scrippsprofiles.ucsd.edu/),<br> [Paul Krummel](https://people.csiro.au/k/p/paul-krummel) | https://github.com/ClimateIndicator/forcing-timeseries |
| Greenhouse gas emissions 1959-2024| [William Lamb](https://www.mcc-berlin.net/en/about/team/lamb-william.html) | https://github.com/ClimateIndicator/GHG-Emissions-Assessment |
| Marine heatwave days 1940-2025 | [Catherine Gregory](https://www.climate.unibe.ch/about_us/team/dr_gregory_catherine/index_eng.html),<br>[Thomas Frölicher](https://www.tfroelicher.com/) | |
| Remaining carbon budgets in 0.1°C increments | [Robin Lamboll](https://www.imperial.ac.uk/people/r.lamboll) | https://github.com/Rlamboll/CarbonBudget |
| Sea level rise 1901-2025 | [Aimée Slangen](https://www.nioz.nl/en/about/organisation/staff/aimee-slangen),<br>[Matthew Palmer](https://www.metoffice.gov.uk/research/people/matt-palmer) | https://github.com/AimeeSlangen/IGCC24_SL |

